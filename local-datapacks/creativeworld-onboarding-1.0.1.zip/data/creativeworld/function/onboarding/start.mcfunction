# @s = a player seen for the first time this season.
scoreboard players add #next_id cw_ob 1
scoreboard players operation @s cw_id = #next_id cw_ob
scoreboard players set @s cw_ob_timer 0
scoreboard players set @s cw_ob_quit 0
scoreboard players set @s cw_ob_rerolls 0
scoreboard players set @s cw_ob_vidx -1
scoreboard players set @s cw_ob_reqt 0
scoreboard players set @s cw_ob_answer 0
scoreboard players enable @s cw_ob_answer
execute store result score #count cw_ob run data get storage creativeworld:onboarding villages
execute if score #count cw_ob matches ..0 run return run scoreboard players set @s cw_ob_state 2
scoreboard players set @s cw_ob_state 1
function creativeworld:onboarding/freeze
function creativeworld:onboarding/place_random
