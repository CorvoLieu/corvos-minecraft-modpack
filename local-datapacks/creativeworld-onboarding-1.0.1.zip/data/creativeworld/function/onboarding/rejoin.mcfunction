# @s = a pending player back after disconnecting. Their village, rerolls and remaining
# time were kept, but chat was cleared on disconnect, so show the menu again.
scoreboard players set @s cw_ob_quit 0
function creativeworld:onboarding/freeze
tellraw @s {"text":"Welcome back! You're still choosing where to start this season.","color":"gold"}
function creativeworld:onboarding/menu
