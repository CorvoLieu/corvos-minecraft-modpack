# @s = a player still choosing, at @s.
scoreboard players add @s cw_ob_timer 1
scoreboard players operation #m cw_ob = @s cw_ob_timer
scoreboard players operation #m cw_ob %= #100 cw_ob
execute if score #m cw_ob matches 0 run function creativeworld:onboarding/freeze
execute if score @s cw_ob_quit matches 1.. run function creativeworld:onboarding/rejoin
execute if score @s cw_ob_timer >= #window cw_ob run return run function creativeworld:onboarding/accept
execute if score @s cw_ob_accept matches 1.. run return run function creativeworld:onboarding/accept
execute if score @s cw_ob_reroll matches 1.. run function creativeworld:onboarding/reroll
execute if score @s cw_ob_friend matches 1.. run function creativeworld:onboarding/friend/list
execute if score @s cw_ob_req matches 1.. run function creativeworld:onboarding/friend/request
execute if score @s cw_ob_reqt matches 1.. run function creativeworld:onboarding/friend/request_tick
