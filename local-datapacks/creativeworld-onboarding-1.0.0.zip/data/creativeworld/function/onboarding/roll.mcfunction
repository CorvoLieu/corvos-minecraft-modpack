$execute store result score #i cw_ob run random value 0..$(max)
