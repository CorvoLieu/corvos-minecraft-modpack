# @s = pending player accepting (or timing out on) the village under them.
scoreboard players set @s cw_ob_accept 0
scoreboard players operation #me cw_ob = @s cw_id
tag @e[type=minecraft:marker,tag=cw_ob_mine] remove cw_ob_mine
execute as @e[type=minecraft:marker,tag=cw_ob_spot] if score @s cw_id = #me cw_ob run tag @s add cw_ob_mine
execute if entity @e[type=minecraft:marker,tag=cw_ob_mine] run tp @s @e[type=minecraft:marker,tag=cw_ob_mine,limit=1]
execute at @s run spawnpoint @s ~ ~ ~
tellraw @s {"text":"Welcome! This village is your spawn point. Good luck this season.","color":"green"}
function creativeworld:onboarding/finish
