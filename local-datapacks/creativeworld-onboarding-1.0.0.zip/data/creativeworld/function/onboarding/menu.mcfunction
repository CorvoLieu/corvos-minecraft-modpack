scoreboard players operation @s cw_ob_left = #max_rerolls cw_ob
scoreboard players operation @s cw_ob_left -= @s cw_ob_rerolls
scoreboard players operation @s cw_ob_secs = #window cw_ob
scoreboard players operation @s cw_ob_secs -= @s cw_ob_timer
scoreboard players operation @s cw_ob_secs /= #20 cw_ob
scoreboard players enable @s cw_ob_accept
scoreboard players enable @s cw_ob_reroll
scoreboard players enable @s cw_ob_friend
scoreboard players enable @s cw_ob_req
tellraw @s ["",{"text":"\nChoose where you start this season\n","color":"gold","bold":true},{"text":"[Accept this village]","color":"green","clickEvent":{"action":"run_command","value":"/trigger cw_ob_accept"},"hoverEvent":{"action":"show_text","contents":"Drop down and make this village your spawn point"}},{"text":"  "},{"text":"[Reroll: ","color":"aqua","clickEvent":{"action":"run_command","value":"/trigger cw_ob_reroll"},"hoverEvent":{"action":"show_text","contents":"Try a different random village"}},{"score":{"name":"@s","objective":"cw_ob_left"},"color":"aqua","clickEvent":{"action":"run_command","value":"/trigger cw_ob_reroll"}},{"text":" left]","color":"aqua","clickEvent":{"action":"run_command","value":"/trigger cw_ob_reroll"}},{"text":"  "},{"text":"[Join a friend]","color":"light_purple","clickEvent":{"action":"run_command","value":"/trigger cw_ob_friend"},"hoverEvent":{"action":"show_text","contents":"Ask an online player to let you start next to them"}},{"text":"\nThis village is accepted automatically in ","color":"gray"},{"score":{"name":"@s","objective":"cw_ob_secs"},"color":"gray"},{"text":" seconds.","color":"gray"}]
