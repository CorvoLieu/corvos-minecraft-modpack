# /function creativeworld:onboarding/admin/status
execute store result score #count cw_ob run data get storage creativeworld:onboarding villages
tellraw @s [{"text":"Onboarding villages loaded: ","color":"gold"},{"score":{"name":"#count","objective":"cw_ob"},"color":"yellow"}]
