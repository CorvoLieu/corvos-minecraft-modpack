# /function creativeworld:onboarding/admin/reset_me -- redo onboarding as the calling player (testing).
function creativeworld:onboarding/unfreeze
scoreboard players operation #me cw_ob = @s cw_id
execute as @e[type=minecraft:marker,tag=cw_ob_spot] if score @s cw_id = #me cw_ob run kill @s
scoreboard players reset @s cw_ob_state
