# @s = player leaving onboarding (accepted, joined a friend, or no village available).
function creativeworld:onboarding/unfreeze
scoreboard players set @s cw_ob_state 2
scoreboard players set @s cw_ob_reqt 0
scoreboard players operation #me cw_ob = @s cw_id
execute as @e[type=minecraft:marker,tag=cw_ob_spot] if score @s cw_id = #me cw_ob run kill @s
scoreboard players enable @s cw_ob_answer
