scoreboard players set @s cw_ob_reroll 0
scoreboard players enable @s cw_ob_reroll
execute if score @s cw_ob_rerolls >= #max_rerolls cw_ob run return run tellraw @s {"text":"No rerolls left. Accept this village or join a friend.","color":"red"}
execute store result score #count cw_ob run data get storage creativeworld:onboarding villages
execute if score #count cw_ob matches ..1 run return run tellraw @s {"text":"There is only one village to choose from.","color":"red"}
scoreboard players add @s cw_ob_rerolls 1
function creativeworld:onboarding/place_random
