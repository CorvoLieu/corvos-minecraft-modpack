# Land @s on solid ground near the village centre, mark the spot, then lift them up for the view.
$execute store success score #ok cw_ob run spreadplayers $(x) $(z) 0 12 false @s
execute if score #ok cw_ob matches 0 if score #tries cw_ob matches ..2 run return run function creativeworld:onboarding/place_try
execute if score #ok cw_ob matches 0 run return run function creativeworld:onboarding/place_failed
kill @e[type=minecraft:marker,tag=cw_ob_old]
execute at @s run summon minecraft:marker ~ ~ ~ {Tags:["cw_ob_spot","cw_ob_new"]}
scoreboard players operation @e[type=minecraft:marker,tag=cw_ob_new] cw_id = @s cw_id
tag @e[type=minecraft:marker,tag=cw_ob_new] remove cw_ob_new
execute at @s run tp @s ~ ~24 ~
function creativeworld:onboarding/menu
