# No safe ground found at 3 villages in a row.
execute if entity @e[type=minecraft:marker,tag=cw_ob_old] run scoreboard players remove @s cw_ob_rerolls 1
execute if entity @e[type=minecraft:marker,tag=cw_ob_old] run tellraw @s {"text":"Couldn't find a safe spot there, so you're staying above this village (reroll refunded).","color":"red"}
execute if entity @e[type=minecraft:marker,tag=cw_ob_old] run function creativeworld:onboarding/menu
execute if entity @e[type=minecraft:marker,tag=cw_ob_old] run return run tag @e[type=minecraft:marker,tag=cw_ob_old] remove cw_ob_old
tellraw @s {"text":"Couldn't find a safe village spot, so you're starting at the world spawn.","color":"red"}
function creativeworld:onboarding/finish
