# @s = pending player. Move them above a random village other than their current one.
scoreboard players set #tries cw_ob 0
scoreboard players operation #me cw_ob = @s cw_id
tag @e[type=minecraft:marker,tag=cw_ob_old] remove cw_ob_old
execute as @e[type=minecraft:marker,tag=cw_ob_spot] if score @s cw_id = #me cw_ob run tag @s add cw_ob_old
function creativeworld:onboarding/place_try
