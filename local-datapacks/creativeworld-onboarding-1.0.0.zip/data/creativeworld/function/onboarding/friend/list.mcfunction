# @s = pending player who clicked [Join a friend].
scoreboard players set @s cw_ob_friend 0
scoreboard players enable @s cw_ob_friend
execute if score @s cw_ob_reqt matches 1.. run return run tellraw @s {"text":"You already have a request waiting for an answer.","color":"red"}
execute unless entity @a[scores={cw_ob_state=2}] run return run tellraw @s {"text":"Nobody who has already settled is online right now.","color":"red"}
tag @s add cw_ob_asker
tellraw @s {"text":"Pick who you want to start next to:","color":"light_purple"}
execute as @a[scores={cw_ob_state=2}] run function creativeworld:onboarding/friend/list_entry
tag @s remove cw_ob_asker
