# @s = candidate friend; the asker is tagged cw_ob_asker.
$tellraw @a[tag=cw_ob_asker] [{"text":"  "},{"selector":"@s","color":"yellow"},{"text":"  "},{"text":"[Ask to join]","color":"light_purple","clickEvent":{"action":"run_command","value":"/trigger cw_ob_req set $(id)"},"hoverEvent":{"action":"show_text","contents":"They get 60 seconds to accept"}}]
