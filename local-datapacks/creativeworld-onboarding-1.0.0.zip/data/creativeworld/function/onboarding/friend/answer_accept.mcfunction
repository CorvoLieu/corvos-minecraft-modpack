# @s = settled player who clicked [Accept]; cw_ob_answer = requester's id.
scoreboard players operation #ans cw_ob = @s cw_ob_answer
scoreboard players operation #me cw_ob = @s cw_id
scoreboard players set @s cw_ob_answer 0
scoreboard players enable @s cw_ob_answer
tag @a remove cw_ob_joiner
tag @s add cw_ob_answerer
execute as @a[scores={cw_ob_state=1}] if score @s cw_id = #ans cw_ob if score @s cw_ob_reqt = #me cw_ob run tag @s add cw_ob_joiner
execute unless entity @a[tag=cw_ob_joiner] run tellraw @s {"text":"That request has expired.","color":"gray"}
execute as @a[tag=cw_ob_joiner] run function creativeworld:onboarding/friend/join
tag @a remove cw_ob_joiner
tag @s remove cw_ob_answerer
