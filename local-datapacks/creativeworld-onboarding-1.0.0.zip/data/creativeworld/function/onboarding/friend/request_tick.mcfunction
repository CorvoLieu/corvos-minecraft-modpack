scoreboard players remove @s cw_ob_reqtime 1
execute if score @s cw_ob_reqtime matches ..0 run function creativeworld:onboarding/friend/expire
