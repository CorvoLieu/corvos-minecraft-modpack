scoreboard players operation @s cw_ob_reqt = #want cw_ob
scoreboard players set @s cw_ob_reqtime 1200
execute store result storage creativeworld:onboarding tmp.id int 1 run scoreboard players get @s cw_id
function creativeworld:onboarding/friend/send_print with storage creativeworld:onboarding tmp
tellraw @s [{"text":"Request sent to ","color":"light_purple"},{"selector":"@a[tag=cw_ob_target]","color":"yellow"},{"text":". They have 60 seconds to accept; you can keep looking around meanwhile.","color":"light_purple"}]
