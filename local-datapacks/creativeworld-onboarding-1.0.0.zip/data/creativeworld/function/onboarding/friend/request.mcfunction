# @s = pending player; cw_ob_req = the chosen friend's id.
scoreboard players operation #want cw_ob = @s cw_ob_req
scoreboard players set @s cw_ob_req 0
scoreboard players enable @s cw_ob_req
execute if score @s cw_ob_reqt matches 1.. run return run tellraw @s {"text":"You already have a request waiting for an answer.","color":"red"}
tag @a remove cw_ob_target
execute as @a[scores={cw_ob_state=2}] if score @s cw_id = #want cw_ob run tag @s add cw_ob_target
execute unless entity @a[tag=cw_ob_target] run tellraw @s {"text":"That player isn't available any more.","color":"red"}
execute if entity @a[tag=cw_ob_target] run function creativeworld:onboarding/friend/send
tag @a remove cw_ob_target
