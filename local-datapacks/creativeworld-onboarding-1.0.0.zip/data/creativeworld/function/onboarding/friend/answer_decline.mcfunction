# @s = settled player who clicked [Decline]; cw_ob_answer = -(requester's id).
scoreboard players operation #ans cw_ob = @s cw_ob_answer
scoreboard players operation #ans cw_ob *= #-1 cw_ob
scoreboard players operation #me cw_ob = @s cw_id
scoreboard players set @s cw_ob_answer 0
scoreboard players enable @s cw_ob_answer
execute as @a[scores={cw_ob_state=1}] if score @s cw_id = #ans cw_ob if score @s cw_ob_reqt = #me cw_ob run function creativeworld:onboarding/friend/declined
