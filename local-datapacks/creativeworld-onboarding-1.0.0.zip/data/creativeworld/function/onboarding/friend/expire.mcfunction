scoreboard players set @s cw_ob_reqt 0
tellraw @s {"text":"Your friend didn't answer in time. You can reroll or ask again.","color":"red"}
function creativeworld:onboarding/menu
