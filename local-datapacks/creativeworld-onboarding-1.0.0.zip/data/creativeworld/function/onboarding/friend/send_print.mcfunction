# @s = requester.
scoreboard players enable @a[tag=cw_ob_target] cw_ob_answer
$tellraw @a[tag=cw_ob_target] [{"selector":"@s","color":"yellow"},{"text":" wants to start the season next to you. ","color":"light_purple"},{"text":"[Accept]","color":"green","clickEvent":{"action":"run_command","value":"/trigger cw_ob_answer set $(id)"},"hoverEvent":{"action":"show_text","contents":"They will be teleported to you"}},{"text":" "},{"text":"[Decline]","color":"red","clickEvent":{"action":"run_command","value":"/trigger cw_ob_answer set -$(id)"}},{"text":" (60 seconds)","color":"gray"}]
