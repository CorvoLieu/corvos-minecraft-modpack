# @s = requester being accepted; the friend is tagged cw_ob_answerer.
tp @s @a[tag=cw_ob_answerer,limit=1]
execute at @s run spawnpoint @s ~ ~ ~
tellraw @s [{"text":"You're starting the season next to ","color":"green"},{"selector":"@a[tag=cw_ob_answerer]","color":"yellow"},{"text":". This is your spawn point now.","color":"green"}]
tellraw @a[tag=cw_ob_answerer] [{"selector":"@s","color":"yellow"},{"text":" joined you.","color":"green"}]
function creativeworld:onboarding/finish
