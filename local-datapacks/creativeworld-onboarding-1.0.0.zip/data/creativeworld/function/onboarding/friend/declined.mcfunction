scoreboard players set @s cw_ob_reqt 0
tellraw @s {"text":"Your request was declined. You can reroll or ask someone else.","color":"red"}
function creativeworld:onboarding/menu
