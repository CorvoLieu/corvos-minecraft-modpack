execute store result storage creativeworld:onboarding tmp.id int 1 run scoreboard players get @s cw_id
function creativeworld:onboarding/friend/list_entry_print with storage creativeworld:onboarding tmp
