# Can look around, can't move, jump or fall; no damage or hunger. Re-applied every 5 s
# (the attribute adds fail harmlessly when the modifier is already there).
attribute @s minecraft:generic.movement_speed modifier add creativeworld:onboarding_freeze -1 add_multiplied_total
attribute @s minecraft:generic.jump_strength modifier add creativeworld:onboarding_freeze -1 add_multiplied_total
attribute @s minecraft:generic.gravity modifier add creativeworld:onboarding_freeze -1 add_multiplied_total
effect give @s minecraft:resistance infinite 255 true
effect give @s minecraft:saturation infinite 0 true
