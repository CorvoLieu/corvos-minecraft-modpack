attribute @s minecraft:generic.movement_speed modifier remove creativeworld:onboarding_freeze
attribute @s minecraft:generic.jump_strength modifier remove creativeworld:onboarding_freeze
attribute @s minecraft:generic.gravity modifier remove creativeworld:onboarding_freeze
effect clear @s minecraft:resistance
effect clear @s minecraft:saturation
effect give @s minecraft:slow_falling 5 0 true
