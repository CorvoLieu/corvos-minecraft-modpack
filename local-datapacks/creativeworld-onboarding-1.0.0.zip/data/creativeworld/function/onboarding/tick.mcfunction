execute as @a unless score @s cw_ob_state matches 1.. at @s run function creativeworld:onboarding/start
execute as @a[scores={cw_ob_state=1}] at @s run function creativeworld:onboarding/pending_tick
execute as @a[scores={cw_ob_answer=1..}] run function creativeworld:onboarding/friend/answer_accept
execute as @a[scores={cw_ob_answer=..-1}] run function creativeworld:onboarding/friend/answer_decline
