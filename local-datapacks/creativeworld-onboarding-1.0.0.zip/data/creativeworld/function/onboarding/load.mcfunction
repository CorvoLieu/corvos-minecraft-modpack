# Season onboarding: new players float above a random scanned village and choose:
# accept it, reroll (max 5), or ask a settled player to join them. 10 minutes max.
# Village list: storage creativeworld:onboarding villages = [{x:..,z:..}, ...]
# written by scripts/scan_villages.py (make scan-villages). Empty list = normal spawn.
scoreboard objectives add cw_ob dummy
scoreboard objectives add cw_id dummy
scoreboard objectives add cw_ob_state dummy
scoreboard objectives add cw_ob_timer dummy
scoreboard objectives add cw_ob_rerolls dummy
scoreboard objectives add cw_ob_left dummy
scoreboard objectives add cw_ob_secs dummy
scoreboard objectives add cw_ob_vidx dummy
scoreboard objectives add cw_ob_reqt dummy
scoreboard objectives add cw_ob_reqtime dummy
scoreboard objectives add cw_ob_accept trigger
scoreboard objectives add cw_ob_reroll trigger
scoreboard objectives add cw_ob_friend trigger
scoreboard objectives add cw_ob_req trigger
scoreboard objectives add cw_ob_answer trigger
scoreboard players set #-1 cw_ob -1
scoreboard players set #20 cw_ob 20
scoreboard players set #100 cw_ob 100
scoreboard players set #max_rerolls cw_ob 5
scoreboard players set #window cw_ob 12000
