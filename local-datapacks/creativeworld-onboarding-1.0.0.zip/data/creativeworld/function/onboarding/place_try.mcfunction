scoreboard players add #tries cw_ob 1
execute store result score #count cw_ob run data get storage creativeworld:onboarding villages
scoreboard players operation #max cw_ob = #count cw_ob
scoreboard players remove #max cw_ob 1
execute if score @s cw_ob_vidx matches 0.. if score #count cw_ob matches 2.. run scoreboard players remove #max cw_ob 1
scoreboard players set #i cw_ob 0
execute store result storage creativeworld:onboarding tmp.max int 1 run scoreboard players get #max cw_ob
execute if score #max cw_ob matches 1.. run function creativeworld:onboarding/roll with storage creativeworld:onboarding tmp
execute if score @s cw_ob_vidx matches 0.. if score #count cw_ob matches 2.. if score #i cw_ob >= @s cw_ob_vidx run scoreboard players add #i cw_ob 1
scoreboard players operation @s cw_ob_vidx = #i cw_ob
execute store result storage creativeworld:onboarding tmp.i int 1 run scoreboard players get #i cw_ob
function creativeworld:onboarding/load_village with storage creativeworld:onboarding tmp
